<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\brod;

class brods extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     *
     */

    public function index()
    {
        $broduct=brod::orderBy('created_at')->paginate(5);
        return view('broduct',compact('broduct'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('createProd');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'product'=>'required',
            'price'=>'required|numeric',
            'Description'=>'required'
        ]);

        $brod=new brod();
       $brod->productName=$request->input('product');
        $brod->price=$request->input('price');
      $brod->description=$request->input('Description');
     $brod->category=$request->input('Category');
     $brod->save();
     return redirect('/broduct')->with('success','product as been successfully Added');
    }

    /**
     * Display the specified resource.h
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $prod=brod::find($id);
        return view('readOneProd',compact('prod'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $prod=brod::find($id);
        return view('update',compact('prod','id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'product'=>'required',
            'price'=>'required|numeric',
            'Description'=>'required'
        ]);

        $brod=brod::find($id);
       $brod->productName=$request->input('product');
        $brod->price=$request->input('price');
      $brod->description=$request->input('Description');
     $brod->category=$request->input('Category');
     $brod->save();
     return redirect('/broduct')->with('success','Product has been successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $brod=brod::find($id);
        $brod->delete();
        return redirect('/broduct')->with('erorr','Product has been successfully deleted');
    }
}
