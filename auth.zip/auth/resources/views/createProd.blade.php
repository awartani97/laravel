
            @extends('layouts.app')

            @section('content')
         
            <div class="container">
                <div class="row justify-content-center">
                        <div class="container">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header"><h3>Create products</h3></div>
                          
            
                            <div class="card-body">
                                @if (session('status'))
                                    <div class="alert alert-success" role="alert">
                                        {{ session('status') }}
                                    </div>
                                @endif
        
                                <div class="container">
                                  
                                        <input type="button" class="btn btn-primary" onclick="location.href='/broduct'" style="float:right" value="Read Products" id="createproduct"> <br><br>
                                <form method="post" action="{{url('/createProduct')}}">
                                    {{ csrf_field() }}
                                        <table  class="table table-bordered">
                                            
                                            <tr>
                                                <th>Product</th>
                                                <td> <input type="text" class="form-control" name="product"  > </td>
                                            </tr>
                                            <tr>
                                                <th>Price</th>
                                                <td> <input type="text" class="form-control" name="price"> </td>
                                            </tr>
                                            <tr>
                                                <th> Description</th>
                                                <td> <textarea class="form-control" name="Description"></textarea> </td>
                                            </tr>
                                            <tr>
                                                <th> Category</th>
                                                <td> <select class="form-control" name="Category">
                                                        <option>Electronics</option>
                                                        <option>Fashion</option>
                                                        <option>Motors</option>
                                                    </select></td>
                                            </tr>
                        
                                                <tr>
                                                    <th></th>
                                                    <td> <input type="submit" value="Create" class="btn btn-primary" name="productt"> </td>
                                                </tr>
                        
                                            </form>
                                        </table>
                                    </div>
                                   
                            
                                    
                                 
                            
            @endsection
             

   
