


@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-center">
            <div class="container">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><h3>Read specific product</h3></div>
              

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

               
                
                    <i class="fas fa-truck-container    ">
        <div class="container">
         
            <input type="button" class="btn btn-primary" onclick="location.href='/broduct'" style="float:right" value="back" > <br><br>
            <table  class="table table-bordered">



                   
                           
                             <tr>   <th>Product</th><td>{{$prod->productName}}</td></tr>
                             <tr>   <th>Price</th><td>{{$prod->price}}</td></tr>
                             <tr>   <th>Description</th><td>{{$prod->description}}</td></tr>
                             <tr>   <th>Category</th><td>{{$prod->category}}</td></tr>

                     
                  
            </table>
        </div></i></div></div></div></div></div></div>
            @endsection
