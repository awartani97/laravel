
            @extends('layouts.app')

            @section('content')
      
        
                                <div class="container">
                                  
                                        <input type="button" class="btn btn-primary" onclick="location.href='/broduct'" style="float:right" value="Back" id="createproduct"> <br><br>
                                <form method="post" action="{{action('brods@update',$id)}}">
                                    @method('put')
                                    {{ csrf_field() }}
                                        <table  class="table table-bordered">
                                            
                                            <tr>
                                                <th>Product</th>
                                            <td> <input type="text" class="form-control" name="product"  value="{{$prod->productName}}" > </td>
                                            </tr>
                                            <tr>
                                                <th>Price</th>
                                                <td> <input type="text" class="form-control" name="price" value="{{$prod->price}}"> </td>
                                            </tr>
                                            <tr>
                                                <th> Description</th>
                                                <td> <textarea class="form-control" name="Description" >{{$prod->description}}</textarea> </td>
                                            </tr>
                                            <tr>
                                                <th> Category</th>
                                                
                                                <td> <select class="form-control" name="Category" >
                                                    <option selected>{{$prod->category}}</option>
                                                        <option>Electronics</option>
                                                        <option>Fashion</option>
                                                        <option>Motors</option>
                                                    </select></td>
                                            </tr>
                        
                                                <tr>
                                                    <th></th>
                                                    <td> <input type="submit" value="Update" class="btn btn-primary" name="productt"> </td>
                                                </tr>
                        
                                            </form>
                                        </table>
                                    </div>
                                   
                            
                                    
                                 
                            
            @endsection
             

   
