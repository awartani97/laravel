<?php $__env->startSection('content'); ?>
<?php if($broduct->count()>0): ?>
<div class="container">
    <div class="row justify-content-center">
            <div class="container">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><h3>products</h3></div>
              

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

               
                
                    <i class="fas fa-truck-container    ">
               
                    
        <table><tr><th> <tr><th><button class="btn btn-success" onclick=location.href='/broduct/create'>Add prouduct</button></th></tr></th></tr></table>
                        <table  class="table table-bordered">
                           
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th> Description</th>
                                    <th> Category</th>
                                    <th> Actions</th>
                                </tr>
                            </thead>
        
                                  
                                                
                                <?php $__currentLoopData = $broduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                
                                    <th><?php echo e($brod->productName); ?></th>
                                    <th><?php echo e($brod->price); ?></th>
                                    <th> <?php echo e($brod->description); ?></th>
                                    <th> <?php echo e($brod->category); ?></th>
                                                
        
                                                    <th><div class=''>
                                                                    <input type='button'  onclick=location.href='/broduct/<?php echo e($brod->id); ?>' value='Read'class='btn btn-primary'> 
                                                                    <input type='button'  onclick=location.href='/broduct/<?php echo e($brod->id); ?>/edit' value='Edit' class='btn btn-success'>
                                                                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModal">
                                                                          Delete</button>
                                                                </div></th></tr>
                                                                <div>           
                                                                        <div class="modal fade" id="myModal">
                                                                                <div class="modal-dialog">
                                                                                  <div class="modal-content">
                                                                                  
                                                                                    <!-- Modal Header -->
                                                                                    <div class="modal-header">
                                                                                      <h4 class="modal-title">Are you sure you wont to deleted</h4>
                                                                                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                                    </div>
                                                                                    
                                                                                   
                                                                                    
                                                                                    <!-- Modal footer -->
                                                                                    <div class="modal-footer">
                                                                                            <input type='button' id='f1' onclick=location.href='<?php echo e(url('/delete/'.$brod->id)); ?>' value='Delete'class='btn btn-danger'>
                                                                                    </div>
                                                                                    
                                                                                  </div>
                                                                                </div>
                                                                              </div>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    </div></table>
                                                                       <div style="color:brown" ><?php echo e($broduct->links()); ?></div>    
                        <?php else: ?>
                       
                        <div class="alert alert-danger" role="alert">
                                <?php echo $__env->make('createProd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <h3>Empty products</h3>
                        </div></i></div></div></div></div></div></div>
                        
                        <?php endif; ?>
                    
                        
                     
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\auth\resources\views/broduct.blade.php ENDPATH**/ ?>