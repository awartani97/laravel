            

            <?php $__env->startSection('content'); ?>
      
        
                                <div class="container">
                                  
                                        <input type="button" class="btn btn-primary" onclick="location.href='/broduct'" style="float:right" value="Back" id="createproduct"> <br><br>
                                <form method="post" action="<?php echo e(action('brods@update',$id)); ?>">
                                    <?php echo method_field('put'); ?>
                                    <?php echo e(csrf_field()); ?>

                                        <table  class="table table-bordered">
                                            
                                            <tr>
                                                <th>Product</th>
                                            <td> <input type="text" class="form-control" name="product"  value="<?php echo e($prod->productName); ?>" > </td>
                                            </tr>
                                            <tr>
                                                <th>Price</th>
                                                <td> <input type="text" class="form-control" name="price" value="<?php echo e($prod->price); ?>"> </td>
                                            </tr>
                                            <tr>
                                                <th> Description</th>
                                                <td> <textarea class="form-control" name="Description" ><?php echo e($prod->description); ?></textarea> </td>
                                            </tr>
                                            <tr>
                                                <th> Category</th>
                                                
                                                <td> <select class="form-control" name="Category" >
                                                    <option selected><?php echo e($prod->category); ?></option>
                                                        <option>Electronics</option>
                                                        <option>Fashion</option>
                                                        <option>Motors</option>
                                                    </select></td>
                                            </tr>
                        
                                                <tr>
                                                    <th></th>
                                                    <td> <input type="submit" value="Update" class="btn btn-primary" name="productt"> </td>
                                                </tr>
                        
                                            </form>
                                        </table>
                                    </div>
                                   
                            
                                    
                                 
                            
            <?php $__env->stopSection(); ?>
             

   

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\auth\resources\views/update.blade.php ENDPATH**/ ?>